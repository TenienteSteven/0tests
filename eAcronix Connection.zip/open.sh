#!/bin/bash
LIBGL_ALWAYS_SOFTWARE=1 ./eANeO.exe.x86
